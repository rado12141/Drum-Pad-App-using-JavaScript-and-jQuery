var snare = new Audio('./audio/snare.mp3');
var ohihat = new Audio('./audio/open-hi-hat.mp3');
var chihat = new Audio('./audio/close-hi-hat.mp3');
var crash = new Audio('./audio/crash.mp3');
var kick = new Audio('./audio/kick.mp3');
var hightom = new Audio('./audio/high-tom.mp3');
var midtom = new Audio('./audio/mid-tom.mp3');
var floortom = new Audio('./audio/floor-tom.mp3');
var ride = new Audio('./audio/ride.mp3');

function play_sound($key = '') {
    const allowed_key = [55, 52, 49, 56, 53, 50, 57, 54, 51];
    if ($.inArray($key, allowed_key) > -1) {
        var audio, pad;
        if ($key == 55) {
            audio = ohihat
            pad = 'ohihat';
        }
        if ($key == 52) {
            audio = crash
            pad = 'crash';
        }
        if ($key == 49) {
            audio = ride
            pad = 'ride';
        }
        if ($key == 56) {
            audio = chihat
            pad = 'chihat';
        }
        if ($key == 53) {
            audio = kick
            pad = 'kick';
        }
        if ($key == 50) {
            audio = snare
            pad = 'snare';
        }
        if ($key == 57) {
            audio = hightom
            pad = 'hightom';
        }
        if ($key == 54) {
            audio = midtom
            pad = 'midtom';
        }
        if ($key == 51) {
            audio = floortom
            pad = 'floortom';
        }
        audio.pause()
        audio.currentTime = 0;
        audio.play()
        animate_pad(pad)
    }
}

function animate_pad($pad = "") {
    if ($pad != "") {
        const allowed_element = ['kick', 'snare', 'hightom', 'midtom', 'floortom', 'ohihat', 'chihat', 'crash', 'ride']
        if ($.inArray($pad, allowed_element) > -1) {
            $(`.pad-item[data-type="${$pad}"]`).removeClass('active')
            $(`.pad-item[data-type="${$pad}"]`).addClass('active')
            setTimeout(() => {
                $(`.pad-item[data-type="${$pad}"]`).removeClass('active')
            }, 100)
        }
    }
}
$(function() {
    $(document).keypress(function(e) {
        console.log(e.which)
        play_sound(e.which)
    })
    $('#drum-pad-field .pad-item').click(function() {
        var type = $(this).attr('data-type')
        const key_codes = {
            "ohihat": 55,
            "crash": 52,
            "ride": 49,
            "chihat": 56,
            "kick": 53,
            "snare": 50,
            "hightom": 57,
            "midtom": 54,
            "floortom": 51,
        }
        if (type != '' && !!key_codes[type])
            play_sound(key_codes[type])
    })
})
$(document).ready(function(e){
    console.log(e.which)
})